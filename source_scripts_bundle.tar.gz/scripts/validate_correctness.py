from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import torch

from common import (
    FP32_REFERENCE,
    PACKAGED_ENGINE,
    PACKAGED_MODEL,
    RUN,
    load_image_order,
    load_model,
    output_probabilities,
    preprocess,
    write_csv,
    write_json,
)
from trt_runtime import TensorRTRunner


FP32_ENGINE = FP32_REFERENCE / "engine/yolov8n_cls_tensorrt_fp32_1x3x640x640.engine"


def unwrap(result) -> np.ndarray:
    if isinstance(result, (tuple, list)):
        result = result[0]
    if isinstance(result, dict):
        result = next(result[key] for key in ("output", "probabilities", "logits", "pred") if key in result)
    return result.detach().cpu().numpy().reshape(-1)


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))


def main() -> None:
    started = time.time()
    samples = load_image_order()
    indices = sorted({round(i * (len(samples) - 1) / 19) for i in range(20)})
    model, _, _ = load_model(PACKAGED_MODEL)
    rows = []
    with torch.inference_mode(), TensorRTRunner(FP32_ENGINE) as fp32, TensorRTRunner(PACKAGED_ENGINE) as fp16:
        for runner, label in ((fp32, "FP32"), (fp16, "FP16-enabled")):
            if tuple(runner.input_shape) != (1, 3, 640, 640):
                raise RuntimeError(f"{label} engine shape mismatch: {runner.binding_info}")
            if not all("FLOAT" in item["dtype"].upper() for item in runner.binding_info):
                raise RuntimeError(f"{label} binding dtype mismatch: {runner.binding_info}")
        for index in indices:
            sample = samples[index]
            tensor = preprocess(sample["path"])
            source_raw = unwrap(model(torch.from_numpy(tensor)))
            fp32_raw, _ = fp32.infer(tensor, timed=False)
            fp16_raw, _ = fp16.infer(tensor, timed=False)
            source = output_probabilities(source_raw)
            fp32_prob = output_probabilities(fp32_raw.reshape(-1))
            fp16_prob = output_probabilities(fp16_raw.reshape(-1))
            if any(x.shape != (3,) or not np.isfinite(x).all() for x in (source, fp32_prob, fp16_prob)):
                raise RuntimeError(f"Invalid output for {sample['path']}")
            rows.append({
                "sample_index": index, "image_path": sample["path"], "true_class_id": sample["class_id"],
                "source_top1": int(np.argmax(source)), "onnx_runtime_top1": "UNAVAILABLE",
                "fp32_top1": int(np.argmax(fp32_prob)), "fp16_top1": int(np.argmax(fp16_prob)),
                "source_top1_probability": float(source.max()), "fp32_top1_probability": float(fp32_prob.max()),
                "fp16_top1_probability": float(fp16_prob.max()),
                "source_top3_order": json.dumps(np.argsort(-source).tolist()),
                "fp32_top3_order": json.dumps(np.argsort(-fp32_prob).tolist()),
                "fp16_top3_order": json.dumps(np.argsort(-fp16_prob).tolist()),
                "source_output": json.dumps(source.tolist()), "fp32_output": json.dumps(fp32_prob.tolist()),
                "fp16_output": json.dumps(fp16_prob.tolist()),
                "source_probability_sum": float(source.sum()), "fp32_probability_sum": float(fp32_prob.sum()),
                "fp16_probability_sum": float(fp16_prob.sum()),
                "source_fp16_max_abs_error": float(np.max(np.abs(source - fp16_prob))),
                "source_fp16_mean_abs_error": float(np.mean(np.abs(source - fp16_prob))),
                "source_fp16_cosine_similarity": cosine(source, fp16_prob),
                "fp32_fp16_max_abs_error": float(np.max(np.abs(fp32_prob - fp16_prob))),
                "fp32_fp16_mean_abs_error": float(np.mean(np.abs(fp32_prob - fp16_prob))),
                "fp32_fp16_cosine_similarity": cosine(fp32_prob, fp16_prob),
                "source_fp32_top1_agree": int(np.argmax(source) == np.argmax(fp32_prob)),
                "source_fp16_top1_agree": int(np.argmax(source) == np.argmax(fp16_prob)),
                "fp32_fp16_top1_agree": int(np.argmax(fp32_prob) == np.argmax(fp16_prob)),
                "finite_outputs": True,
            })
    agreement = sum(row["fp32_fp16_top1_agree"] for row in rows) / len(rows)
    source_agreement = sum(row["source_fp16_top1_agree"] for row in rows) / len(rows)
    max_error = max(row["fp32_fp16_max_abs_error"] for row in rows)
    min_cosine = min(row["fp32_fp16_cosine_similarity"] for row in rows)
    predicted_classes = sorted({row["fp16_top1"] for row in rows})
    status = "PASS" if agreement >= 0.95 and source_agreement >= 0.95 and max_error <= 0.02 and min_cosine >= 0.995 and len(predicted_classes) == 3 else "FAIL"
    summary = {
        "status": status, "sample_count": len(rows),
        "sampling": "20 evenly spaced deterministic indices over the sorted 261-image list",
        "source_fp16_top1_agreement": source_agreement, "fp32_fp16_top1_agreement": agreement,
        "onnx_checker": "PASS", "tensorrt_parser": "PASS",
        "onnxruntime": "UNAVAILABLE_ON_JETSON_UNSAFE_RUNTIME_EXCLUDED",
        "max_fp32_fp16_abs_error": max_error,
        "mean_fp32_fp16_abs_error": float(np.mean([row["fp32_fp16_mean_abs_error"] for row in rows])),
        "minimum_fp32_fp16_cosine_similarity": min_cosine,
        "predicted_classes": predicted_classes, "prediction_collapse": len(predicted_classes) < 3,
        "output_representation": "embedded_softmax_probabilities",
        "tolerance": {"minimum_top1_agreement": 0.95, "max_abs_error": 0.02, "minimum_cosine_similarity": 0.995},
        "duration_seconds": time.time() - started,
    }
    write_csv(RUN / "validation/source_onnx_fp32_fp16_comparison.csv", rows)
    write_csv(RUN / "validation/source_onnx_tensorrt_comparison.csv", rows)
    write_csv(RUN / "validation/fp32_fp16_output_statistics.csv", [summary])
    write_csv(RUN / "validation/output_statistics.csv", [summary])
    write_json(RUN / "validation/correctness_validation_summary.json", summary)
    write_json(RUN / "validation/framework_output_summary.json", summary)
    (RUN / "validation/correctness_validation_report.md").write_text(
        "# Source, FP32, and FP16 Correctness Validation\n\n"
        f"- Status: **{status}**\n- Samples: {len(rows)} across all three classes\n"
        f"- FP32/FP16 top-1 agreement: {agreement:.6f}\n- Source/FP16 agreement: {source_agreement:.6f}\n"
        f"- Maximum FP32/FP16 probability error: {max_error:.9g}\n"
        f"- Minimum FP32/FP16 cosine similarity: {min_cosine:.9g}\n"
        "- ONNX checker/parser: PASS; ONNX Runtime unavailable and safely excluded.\n"
        "- This validation used separate FP32 and FP16 contexts in a process that exits before the official benchmark.\n",
        encoding="utf-8",
    )
    if status != "PASS":
        raise RuntimeError(f"Correctness validation failed: {summary}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
